#!/bin/bash

# install necessary software
#  iperf is not in Amazon linux AMI packages, weird?  perhaps do a different install here
yum install -y tmux iptraf iotop htop
# iperf not available on Wowza base OS (Amazon AMI / Centos)
# Install script from https://iperf.fr/
wget https://iperf.fr/download/iperf_2.0.2/iperf_2.0.2-4_amd64 ; chmod +x iperf_2.0.2-4_amd64 ; sudo mv iperf_2.0.2-4_amd64 /usr/bin/iperf

